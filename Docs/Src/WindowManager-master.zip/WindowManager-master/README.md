WindowManager
=============

A utility program to alter the border style of active windows. (For example, removing the border from games!)
In addition, it has a program profile section, allowing certain settings to be automatically applied upon that program's startup.

